# Branching Strategies

1. **Feature Branching**: Each feature is developed in its branch.
2. **Git Flow**: A structured branching model.
3. **Trunk-Based Development**: Use a single branch with short-lived feature branches.