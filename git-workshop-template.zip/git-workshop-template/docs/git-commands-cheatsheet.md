# Git Commands Cheatsheet

- `git init`: Initialize a repository.
- `git clone`: Clone a repository.
- `git branch`: List branches.
- `git checkout`: Switch branches.