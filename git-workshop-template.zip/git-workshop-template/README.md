# Git Workshop Template

Welcome to the Git Workshop! This repository is designed to learn Git and GitHub concepts through hands-on practice.
Follow the instructions in each `tasks/` folder to complete your assignments.