# Task 1: Create a Branch

1. Create a new branch named `feature/task1`.
2. Add your name to the `solution.md` file.
3. Commit and push your changes.