# Task 2: Resolve a Merge Conflict

1. Create a conflict by editing `solution.md` in two branches.
2. Resolve the conflict and merge the branches.